import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "BIO_TRACK_ATTENDENCE.settings")

application = get_wsgi_application()

# Start scheduler after app is ready
try:
    from attendence.apps import AttendenceConfig
    AttendenceConfig.ready(None)
except Exception as e:
    import logging
    logger = logging.getLogger(__name__)
    logger.error(f"Failed to start scheduler: {str(e)}")