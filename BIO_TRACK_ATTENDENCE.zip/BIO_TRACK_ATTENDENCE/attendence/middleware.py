from django.utils.deprecation import MiddlewareMixin
from django.shortcuts import redirect
from django.urls import reverse

class NoCacheMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        response['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        response['Pragma'] = 'no-cache'
        response['Expires'] = '0'
        return response

class EmployeeSessionMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # List of employee URLs that require authentication
        emp_urls = [
            '/emp_dashboard/',
            '/emp/apply-leave/',
        ]
        
        if any(request.path.startswith(url) for url in emp_urls):
            if 'emp_id' not in request.session:
                return redirect(reverse('emp_login'))
        
        response = self.get_response(request)
        return response
