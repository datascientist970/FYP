"""========IMPORT MODULES/HEADERFILES========"""
from django.db import models
from datetime import date, datetime, time
import base64
import logging
import cv2
import pickle
import numpy as np
from django.contrib.auth.models import User, AbstractUser, BaseUserManager
from django.core.exceptions import ValidationError
from django.conf import settings
from django.utils import timezone
from django.db import transaction
from scipy.spatial.distance import cosine
import os
from django.core.cache import cache
from django.db.models import Q, Count, Sum,F,Max
from numpy.linalg import norm

logger = logging.getLogger(__name__)

def normalize_embedding(embedding):
    """Normalize embedding vector to unit length (L2 norm)"""
    if embedding is None:
        return None
    
    # Convert to numpy array if it isn't already
    embedding = np.asarray(embedding, dtype=np.float32)
    
    # Handle zero vector case
    norm_val = norm(embedding)
    if norm_val <= 1e-12:  # practically zero
        return embedding
    
    return embedding / norm_val


"""========SYSTEM SETTINGS MODEL========"""
class SystemSettings(models.Model):
    face_match_threshold = models.FloatField(
        default=0.5,  
        help_text="Similarity threshold for face matching (0.0 to 1.0)"
    )
    absent_time = models.TimeField(
        default=time(12, 0),
        help_text="Time after which employees are marked absent automatically"
    )
    max_login_attempts = models.IntegerField(
        default=3,
        help_text="Maximum allowed failed login attempts before lockout"
    )
    lockout_time = models.IntegerField(
        default=300,
        help_text="Lockout duration in seconds after max attempts reached"
    )
    annual_leave_limit = models.PositiveIntegerField(
        default=20,
        help_text="Maximum annual leave days allowed per year"
    )
    sick_leave_limit = models.PositiveIntegerField(
        default=10,
        help_text="Maximum sick leave days allowed per year"
    )
    last_leave_limit_update = models.DateTimeField(
        null=True,
        blank=True,
        help_text="When leave limits were last changed"
    )

    class Meta:
        verbose_name_plural = "System Settings"

    def __str__(self):
        return "System Configuration"

    @classmethod
    def load(cls):
        try:
            obj, created = cls.objects.get_or_create(pk=1)
            return obj
        except Exception as e:
            logger.warning(f"Could not load SystemSettings: {str(e)}")
        # Return a default instance without saving to DB
            return cls()

    def save(self, *args, **kwargs):
        """Custom save to handle system setting changes and adjust employee leaves accordingly"""
        self.pk = 1  # Singleton enforcement

    # Detect changes
        if self.pk:
            try:
                old_settings = SystemSettings.objects.get(pk=1)
                annual_changed = (self.annual_leave_limit != old_settings.annual_leave_limit)
                sick_changed = (self.sick_leave_limit != old_settings.sick_leave_limit)
            except SystemSettings.DoesNotExist:
                annual_changed = False
                sick_changed = False
        else:
            annual_changed = False
            sick_changed = False

    # Save first
        super().save(*args, **kwargs)

        if annual_changed or sick_changed:
            with transaction.atomic():
            
                from .models import Employee, LeaveApplication

            # Update last update time
                self.last_leave_limit_update = timezone.now()
                super().save(update_fields=['last_leave_limit_update'])

                # Fetch all employees
                employees = Employee.objects.all()

            # 🛠 Adjust leave balances without saving yet
                for emp in employees:
                    emp.annual_leave_remaining = max(0, self.annual_leave_limit - emp.total_leave_taken)
                    emp.sick_leave_remaining = max(0, self.sick_leave_limit - emp.total_leave_taken)

            
                Employee.objects.bulk_update(employees, ['annual_leave_remaining', 'sick_leave_remaining'])

            # Handle pending leave applications
                pending_applications = LeaveApplication.objects.filter(status='Pending')

                for application in pending_applications:
                    employee = application.employee
                    leave_days = (application.end_date - application.start_date).days + 1

                    if application.leave_type == 'Annual Leave':
                        if employee.annual_leave_remaining < leave_days:
                            application.status = 'Rejected'
                            application.admin_comment = 'Auto-rejected due to leave limit update.'
                            application.save()

                    elif application.leave_type == 'Sick Leave':
                        if employee.sick_leave_remaining < leave_days:
                            application.status = 'Rejected'
                            application.admin_comment = 'Auto-rejected due to leave limit update.'
                            application.save()

    def get_leave_limits(self):
        return {
            'annual': self.annual_leave_limit,
            'sick': self.sick_leave_limit,
            'last_updated': self.last_leave_limit_update
        }

    def validate_leave_limits(self):
        errors = []
        if self.annual_leave_limit < 1:
            errors.append("Annual leave limit must be at least 1 day")
        if self.sick_leave_limit < 1:
            errors.append("Sick leave limit must be at least 1 day")
        return errors
    


"""========USER AUTHENTICATION MODELS========"""
class UserManager(BaseUserManager):
    def create_user(self, username, email, password=None, **extra_fields):
        if not email:
            raise ValueError("Email is required")
        email = self.normalize_email(email)
        user = self.model(username=username, email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        if self.model.objects.filter(is_superuser=True).exists():
            raise ValidationError("Only one superuser is allowed in the system")
        return self.create_user(username, email, password, **extra_fields)

class User(AbstractUser):
    objects = UserManager()

"""========EMPLOYEE MODEL========"""
class Employee(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        null=True, 
        blank=True
    )
    name = models.CharField(max_length=255, db_index=True)
    designation = models.CharField(max_length=255, db_index=True)
    department = models.CharField(max_length=255, default='IT', db_index=True)
    join_date = models.DateField(auto_now_add=True)
    employee_id = models.CharField(
        max_length=50, 
        unique=True, 
        editable=False,
        db_index=True
    )
    photo = models.ImageField(
        upload_to='employee_photos/', 
        null=True, 
        blank=True,
        help_text="Employee profile photo"
    )
    # face_embedding = models.BinaryField(
    #     null=True, 
    #     blank=True,
    #     help_text="Face embedding vector for recognition"
    # )
    annual_leave_remaining = models.PositiveIntegerField(
        default=20,
        help_text="Remaining annual leave days"
    )
    sick_leave_remaining = models.PositiveIntegerField(
        default=10,
        help_text="Remaining sick leave days"
    )
    total_leave_taken = models.PositiveIntegerField(
        default=0,
        help_text="Total leave days taken"
    )
    is_active = models.BooleanField(
        default=True,
        help_text="Whether employee is currently active"
    )
    last_attendance_date = models.DateField(
        null=True,
        blank=True,
        help_text="Last date when attendance was marked"
    )
    # estimated_age = models.PositiveSmallIntegerField(null=True, blank=True)
    # gender = models.CharField(max_length=10, null=True, blank=True)
    # dominant_emotion = models.CharField(max_length=20, null=True, blank=True)
    class Meta:
        verbose_name_plural = "Employees"
        indexes = [
            models.Index(fields=['name', 'department']),
            models.Index(fields=['employee_id']),
            models.Index(fields=['is_active']),
        ]
        ordering = ['name']

    def __str__(self):
        return f"{self.name} ({self.employee_id})"

    def clean(self):
        """Validate employee data before saving"""
        settings = SystemSettings.load()
        
        # Validate leave balances don't exceed system limits
        if self.annual_leave_remaining > settings.annual_leave_limit:
            raise ValidationError(
                f"Annual leave remaining ({self.annual_leave_remaining}) cannot exceed system limit of {settings.annual_leave_limit}"
            )
            
        if self.sick_leave_remaining > settings.sick_leave_limit:
            raise ValidationError(
                f"Sick leave remaining ({self.sick_leave_remaining}) cannot exceed system limit of {settings.sick_leave_limit}"
            )
        
        # Ensure leave balances aren't negative
        if self.annual_leave_remaining < 0:
            raise ValidationError("Annual leave remaining cannot be negative")
            
        if self.sick_leave_remaining < 0:
            raise ValidationError("Sick leave remaining cannot be negative")
    def generate_employee_id(self):
        """Generate ID in format: DEPT-DESIG-0001 (auto-incremented by designation)"""
        if not self.designation:
            raise ValueError("Designation is required to generate employee ID")
            
        # Get department code (first 3 letters)
        dept_code = self.department[:3].upper() if self.department else "GEN"
        
        # Get designation code (first 3 letters)
        desig_code = self.designation[:3].upper()
        
        # Find max existing ID for this designation
        max_id = Employee.objects.filter(
            designation=self.designation
        ).aggregate(max_id=Max('employee_id'))['max_id']
        
        if max_id:
            try:
                # Extract number and increment (handles existing IDs in format)
                last_num = int(max_id.split('-')[-1])
                new_num = last_num + 1
            except (ValueError, IndexError):
                # If existing ID format is invalid, start from 1
                new_num = 1
        else:
            # First employee with this designation
            new_num = 1
            
        return f"{dept_code}-{desig_code}-{new_num:04d}"

    def save(self, *args, **kwargs):
        if not self.employee_id:
            self.employee_id = self.generate_employee_id()
        super().save(*args, **kwargs)

    # def set_face_embedding(self, embedding):
    #     """Store face embedding vector"""
    #     if embedding is None:
    #         raise ValueError("Embedding cannot be None")
        
    #     if not isinstance(embedding, np.ndarray):
    #         embedding = np.array(embedding, dtype=np.float32)
            
    #     if embedding.ndim != 1:
    #         raise ValueError("Embedding must be 1D array")
        
    #     self.face_embedding = pickle.dumps(embedding)

    # def get_face_embedding(self):
    #     """Retrieve face embedding vector"""
    #     if not self.face_embedding:
    #         return None
        
    #     try:
    #         return pickle.loads(self.face_embedding)
    #     except (pickle.PickleError, AttributeError):
    #         return None

    def get_leave_balance(self, leave_type):
        """Get remaining leave balance for specific type"""
        if leave_type == 'Annual':
            return self.annual_leave_remaining
        elif leave_type == 'Sick':
            return self.sick_leave_remaining
        return 0

    def take_leave(self, leave_type, days):
        """Deduct leave days from balance"""
        if leave_type == 'Annual':
            if self.annual_leave_remaining < days:
                raise ValueError("Insufficient annual leave balance")
            self.annual_leave_remaining -= days
        elif leave_type == 'Sick':
            if self.sick_leave_remaining < days:
                raise ValueError("Insufficient sick leave balance")
            self.sick_leave_remaining -= days
        else:
            raise ValueError("Invalid leave type")
            
        self.total_leave_taken += days
        self.save()

    def get_attendance_summary(self, year=None, month=None):
        """Get attendance summary for period"""
        from .models import Attendance
        
        filters = {'emp': self}
        if year:
            filters['date__year'] = year
        if month:
            filters['date__month'] = month
            
        attendance = Attendance.objects.filter(**filters)
        
        return {
            'present': attendance.filter(status='Present').count(),
            'absent': attendance.filter(status='Absent').count(),
            'leave': attendance.filter(status='Leave').count(),
            'total': attendance.count()
        }

    def update_last_attendance(self):
        """Update last attendance date"""
        from .models import Attendance
        last_attendance = Attendance.objects.filter(
            emp=self
        ).order_by('-date').first()
        
        if last_attendance:
            self.last_attendance_date = last_attendance.date
            self.save(update_fields=['last_attendance_date'])

    @property
    def photo_url(self):
        """Get absolute URL for employee photo"""
        if self.photo and hasattr(self.photo, 'url'):
            return self.photo.url
        return os.path.join(settings.STATIC_URL, 'images/default_employee.png')

    @classmethod
    def active_employees(cls):
        """Get queryset of active employees"""
        return cls.objects.filter(is_active=True)
    
    def deduct_leave(self, leave_type, days):
        """Deduct leave days from balance"""
        if leave_type == 'Annual Leave':
            if self.annual_leave_remaining < days:
                raise ValueError("Insufficient annual leave balance")
            self.annual_leave_remaining -= days
        elif leave_type == 'Sick Leave':
            if self.sick_leave_remaining < days:
                raise ValueError("Insufficient sick leave balance")
            self.sick_leave_remaining -= days
        else:
            raise ValueError("Invalid leave type")
            
        self.total_leave_taken += days
        self.save()

    @classmethod
    def update_all_leave_balances(cls, annual_adjustment=0, sick_adjustment=0):
        """Bulk update leave balances for all employees"""
        update_params = {}
        
        if annual_adjustment != 0:
            update_params['annual_leave_remaining'] = F('annual_leave_remaining') + annual_adjustment
            
        if sick_adjustment != 0:
            update_params['sick_leave_remaining'] = F('sick_leave_remaining') + sick_adjustment
            
        if update_params:
            cls.objects.update(**update_params)

class EmployeeEmbedding(models.Model):
    """
    Stores face embedding vectors for employee recognition
    """
    employee = models.OneToOneField(
        'Employee',
        on_delete=models.CASCADE,
        related_name='embedding',
        verbose_name="Associated Employee"
    )
    vector = models.JSONField(
        help_text="Stores the face embedding vector as JSON"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="When the embedding was created"
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        help_text="When the embedding was last updated"
    )
    version = models.CharField(
        max_length=20,
        default='v1',
        help_text="Embedding model version"
    )

    class Meta:
        verbose_name = "Employee Face Embedding"
        verbose_name_plural = "Employee Face Embeddings"
        indexes = [
            models.Index(fields=['employee']),
        ]

    def __str__(self):
        return f"Face embedding for {self.employee.name} ({self.version})"

    @staticmethod
    def normalize_embedding(embedding):
        """Normalize embedding vector to unit length (L2 norm)"""
        if embedding is None:
            return None
            
        embedding = np.asarray(embedding, dtype=np.float32)
        norm_val = norm(embedding)
        
        # Handle zero vector case
        if norm_val <= 1e-12:  # practically zero
            return embedding
            
        return embedding / norm_val

    def set_embedding(self, embedding):
        """
        Store a normalized face embedding vector
        Args:
            embedding: Face embedding vector (list or numpy array)
        """
        if embedding is None:
            raise ValueError("Embedding cannot be None")
            
        # Convert to numpy array and normalize
        embedding = np.asarray(embedding, dtype=np.float32).flatten()
        normalized = self.normalize_embedding(embedding)
        
        if normalized is None:
            raise ValueError("Invalid embedding - normalization failed")
            
        self.vector = normalized.tolist()

    def get_embedding(self):
        """
        Retrieve the normalized embedding vector
        Returns:
            numpy.ndarray: Normalized embedding vector
        """
        if not self.vector:
            return None
            
        try:
            embedding = np.asarray(self.vector, dtype=np.float32)
            return self.normalize_embedding(embedding)
        except Exception as e:
            logger.error(f"Error loading embedding for {self.employee}: {str(e)}")
            return None

    def compare_with(self, other_embedding, threshold=0.5):
        """
        Compare this embedding with another embedding
        Args:
            other_embedding: Embedding to compare with
            threshold: Similarity threshold (default: 0.5)
        Returns:
            tuple: (similarity_score, is_match)
        """
        current_embedding = self.get_embedding()
        other_embedding = self.normalize_embedding(other_embedding)
        
        if current_embedding is None or other_embedding is None:
            return 0.0, False
            
        # Calculate cosine similarity
        similarity = np.dot(current_embedding, other_embedding)
        return similarity, similarity >= threshold

    @classmethod
    def find_best_match(cls, query_embedding, threshold=0.5):
        """
        Find the best matching employee for a given embedding
        Args:
            query_embedding: Embedding vector to match
            threshold: Minimum similarity threshold
        Returns:
            tuple: (Employee, similarity_score) or (None, 0.0)
        """
        if query_embedding is None:
            return None, 0.0
            
        query_embedding = cls.normalize_embedding(query_embedding)
        best_match = None
        best_score = -1.0
        
        # Get all embeddings with their employees
        embeddings = cls.objects.select_related('employee').all()
        
        for emb in embeddings:
            try:
                db_embedding = emb.get_embedding()
                if db_embedding is None:
                    continue
                    
                similarity = np.dot(query_embedding, db_embedding)
                
                if similarity > best_score:
                    best_score = similarity
                    best_match = emb.employee
            except Exception as e:
                logger.error(f"Error comparing with {emb.employee}: {str(e)}")
                continue
                
        return (best_match, best_score) if best_score >= threshold else (None, best_score)

    @classmethod
    def create_for_employee(cls, employee, embedding):
        """
        Create a new embedding record for an employee
        Args:
            employee: Employee instance
            embedding: Face embedding vector
        Returns:
            EmployeeEmbedding: The created instance
        """
        if not employee or not hasattr(employee, 'id'):
            raise ValueError("Invalid employee")
            
        # Delete any existing embedding
        cls.objects.filter(employee=employee).delete()
        
        # Create new embedding
        emb = cls(employee=employee)
        emb.set_embedding(embedding)
        emb.save()
        return emb

"""========ATTENDANCE MODEL========"""
class Attendance(models.Model):
    STATUS_CHOICES = [
        ("Present", "Present"), 
        ("Absent", "Absent"),
        ("Leave", "Leave"),
    ]
    emp = models.ForeignKey(
        Employee, 
        on_delete=models.CASCADE, 
        db_index=True,
        related_name='attendance_records'
    )
    date = models.DateField(db_index=True)
    time = models.TimeField()
    status = models.CharField(
        max_length=10, 
        choices=STATUS_CHOICES, 
        db_index=True
    )
    is_locked = models.BooleanField(
        default=False,
        help_text="Locked records cannot be modified"
    )
    marked_by = models.CharField(
        max_length=20, 
        choices=[
            ("System", "System"),
            ("Admin", "Admin")
        ], 
        default="System"
    )

    class Meta:
        unique_together = ('emp', 'date')
        ordering = ['-date', 'emp__name']
        verbose_name_plural = "Attendance Records"

    @transaction.atomic
    def save(self, *args, **kwargs):
        if kwargs.pop('skip_checks', False):
            super().save(*args, **kwargs)
            return
        
        existing = Attendance.objects.select_for_update().filter(
            emp=self.emp, 
            date=self.date
        ).first()
        
        if existing:
            raise ValueError(f"Attendance already exists: {existing.status}")
        
        settings = SystemSettings.load()
        if datetime.now().time() >= settings.absent_time:
            self.status = "Absent"
            self.is_locked = True
        
        super().save(*args, **kwargs)

"""========LEAVE APPLICATION MODEL========"""
class LeaveApplication(models.Model):
    LEAVE_TYPES = [
        ('Annual', 'Annual Leave'),
        ('Sick', 'Sick Leave'),
        ('Emergency', 'Emergency Leave'),
        ('Other', 'Other Leave'),
    ]
    
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected'),
    ]
    
    employee = models.ForeignKey(
        Employee, 
        on_delete=models.CASCADE,
        related_name='leave_applications'
    )
    leave_type = models.CharField(
        max_length=20, 
        choices=LEAVE_TYPES, 
        default='Annual'
    )  
    dept = models.CharField(
    max_length=50,  
    default='IT'    
) 
    application_date = models.DateTimeField(auto_now_add=True)
    reason = models.TextField()
    start_date = models.DateField()
    end_date = models.DateField()
    attachment = models.FileField(
        upload_to='leave_attachments/', 
        null=True, 
        blank=True
    )
    status = models.CharField(
        max_length=10, 
        choices=STATUS_CHOICES, 
        default='Pending'
    )
    admin_comment = models.TextField(null=True, blank=True)
    days_count = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['-application_date']
        verbose_name_plural = "Leave Applications"

    def __str__(self):
        return f"{self.employee.name} - {self.start_date} to {self.end_date} ({self.status})"
    
    @property
    def duration(self):
        return (self.end_date - self.start_date).days + 1
    
    def save(self, *args, **kwargs):
        # Calculate duration when saving
        self.days_count = (self.end_date - self.start_date).days + 1
        super().save(*args, **kwargs)
    
    @property
    def duration(self):
        return self.days_count

"""========ABSENT TIME SETTINGS========"""
class AbsentTimeSettings(models.Model):
    absent_time = models.TimeField(default=time(12, 0))

    class Meta:
        verbose_name_plural = "Absent Time Settings"

    def __str__(self):
        return f"Absent Time: {self.absent_time.strftime('%H:%M')}"
    
class EmployeeRegistrationRequest(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ]
    
    name = models.CharField(max_length=255)
    designation = models.CharField(max_length=255)
    department = models.CharField(max_length=255)
    photo = models.ImageField(upload_to='registration_requests/')
    face_embedding = models.JSONField()  
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    request_date = models.DateTimeField(auto_now_add=True)
    decision_date = models.DateTimeField(null=True, blank=True)
    admin_comment = models.TextField(null=True, blank=True)
    
    class Meta:
        ordering = ['-request_date']
        
    def __str__(self):
        return f"{self.name} - {self.get_status_display()}"
    
    def approve(self):
        """Create an active employee from this request"""
        try:
            with transaction.atomic():
                # Create employee
                employee = Employee.objects.create(
                    name=self.name,
                    designation=self.designation,
                    department=self.department,
                    photo=self.photo
                )
                
                # Create face embedding
                EmployeeEmbedding.objects.create(
                    employee=employee,
                    vector=self.face_embedding,
                    version="facenet512_v1"
                )
                
                # Update request status
                self.status = 'approved'
                self.decision_date = timezone.now()
                self.save()
                
                return employee
        except Exception as e:
            logger.error(f"Error approving registration request {self.id}: {str(e)}")
            raise
    
    def reject(self, comment=""):
        """Mark request as rejected"""
        self.status = 'rejected'
        self.admin_comment = comment
        self.decision_date = timezone.now()
        self.save()

        