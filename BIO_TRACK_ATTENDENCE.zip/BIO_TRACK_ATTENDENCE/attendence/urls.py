"""========IMPORT MODULES/HEADER FILES========"""

from django.urls import path
from . import views

"""========ROUTING SETTING/URLS MANAGEMENT========"""

urlpatterns = [
    path('', views.home, name='home'),
    # path('register/', views.register_employee_page, name='register_employee_page'),
    path('register_employee/', views.register_employee, name='register_employee'),
    path('mark_attendance', views.mark_attendance, name='mark_attendance'),
    path('export_attendance', views.export_attendance, name='export_attendance'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('attendance/', views.attendance_view, name='attendance'),
    path('analysis/', views.analysis, name='analysis'),
    path('detect-face/', views.detect_face, name='detect_face'),
    path('mysetting/', views.mysetting, name='mysetting'),
    path('all_users/', views.all_users, name='all_users'),
    path('present_users/', views.present_users, name='present_users'),
    path('absent_users/', views.absent_users, name='absent_users'),
    path('edit_user/<int:user_id>/', views.edit_user, name='edit_user'),
    path("analyze-face/", views.analyze_face, name="analyze_face"),
    path('delete_user/<int:user_id>/', views.delete_user, name='delete_user'),
    path('update-absent-time/', views.update_absent_time, name='update_absent_time'),
    path('emp_login/', views.emp_login, name='emp_login'),
    path('employee-portal/', views.EmployeePortalView.as_view(), name='employee_portal'),
    path('registration-requests/', views.registration_requests, name='registration_requests'),
    path('process-request/<int:request_id>/', views.process_registration_request, name='process_registration_request'),
    path('check_registration_status/', views.check_registration_status, name='check_registration_status'),
    path('emp_dashboard/', views.emp_dashboard, name='emp_dashboard'),
    path('emp_apply-leave/', views.apply_leave, name='apply_leave'),
    path('leave_management/', views.leave_management, name='leave_management'),
    path('process_leave/', views.process_leave, name='process_leave'),
    path('emp_logout/', views.emp_logout, name='emp_logout'),
    path('leave-management/', views.leave_management, name='leave_management'),
    path('leave/process/<int:app_id>/<str:action>/', views.process_leave, name='process_leave'),
    path('update_leave_limits/', views.update_leave_limits, name='update_leave_limits'),
]