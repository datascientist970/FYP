from django.db.models.signals import post_migrate, pre_save
from django.dispatch import receiver
from django.core.exceptions import ValidationError
from django.contrib.auth import get_user_model
from django.db import connection
import logging

logger = logging.getLogger(__name__)

@receiver(pre_save)
def prevent_multiple_superusers(sender, **kwargs):
    User = get_user_model()
    if sender == User:
        instance = kwargs['instance']
        if instance.is_superuser and not instance.pk:  # New superuser
            if User.objects.filter(is_superuser=True).exists():
                raise ValidationError("Only one superuser is allowed in the system")

@receiver(post_migrate)
def init_system(sender, **kwargs):
    if sender.name == 'attendence':
        try:
            # Check if tables exist first
            table_names = connection.introspection.table_names()
            
            # Initialize system settings if table exists
            if 'attendence_systemsettings' in table_names:
                from .models import SystemSettings
                SystemSettings.load()
                
            # Start scheduler if tables exist
            if 'django_apscheduler_djangojob' in table_names:
                from .scheduler import start_scheduler
                start_scheduler()
                
        except Exception as e:
            logger.error(f"Error initializing system: {e}")