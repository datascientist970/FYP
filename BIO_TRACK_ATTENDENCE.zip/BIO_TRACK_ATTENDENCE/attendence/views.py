from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.generic import TemplateView
from django.urls import reverse 
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib import messages
from django.http import HttpResponse, JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.cache import never_cache
from django.core.cache import cache
from ultralytics import YOLO
from django.views.decorators.http import require_http_methods
import torch
from datetime import timedelta
from django.core.files.storage import FileSystemStorage
from django.utils.timezone import now
from django.conf import settings as S
from django.db import transaction
from django.db.models import Q, Count, Case, When, F, FloatField,Sum
from .models import Employee, Attendance, SystemSettings, AbsentTimeSettings, User,LeaveApplication,EmployeeEmbedding,EmployeeRegistrationRequest
import os
import json
import base64
import time as t
import logging  
import pickle
import cv2
import numpy as np
from datetime import date, time, datetime
import csv
from deepface import DeepFace
from apscheduler.schedulers.background import BackgroundScheduler
from django_apscheduler.jobstores import DjangoJobStore
from django_apscheduler import util
from scipy.spatial.distance import cosine
from attendence.scheduler import scheduler_manager
from django.views.decorators.csrf import csrf_exempt
from django import template

register = template.Library()

logger = logging.getLogger(__name__)

FACE_DETECTOR = YOLO('F:/WEB ENGINEERING/FYP/BIO_TRACK_ATTENDENCE/attendence/model/yolov8n-face.pt') 
if torch.cuda.is_available():
    FACE_DETECTOR.to('cuda')
    # Warmup GPU
    dummy_img = np.zeros((640, 640, 3), dtype=np.uint8)
    _ = FACE_DETECTOR(dummy_img)
# Cache for employee embeddings
_employee_embeddings_cache = None
_last_cache_update = None
_CACHE_TIMEOUT = 3600  # 1 hour

def detect_faces_yolo(image, conf_threshold=0.5):
    """Detect faces using YOLOv8 face detector"""
    try:
        results = FACE_DETECTOR(image, verbose=False, imgsz=640)
        boxes = []
        for result in results:
            for box in result.boxes:
                if box.conf.item() > conf_threshold:
                    x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                    boxes.append((x1, y1, x2, y2))
        return boxes if boxes else None
    except Exception as e:
        logger.error(f"Face detection error: {str(e)}")
        return None

@csrf_exempt
def detect_face(request):
    """Endpoint for real-time face detection"""
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            image_data = data.get("image")
            
            if not image_data or ';base64,' not in image_data:
                return JsonResponse({"error": "Invalid image"}, status=400)

            img_bytes = base64.b64decode(image_data.split(';base64,')[1])
            img = cv2.imdecode(np.frombuffer(img_bytes, np.uint8), cv2.IMREAD_COLOR)
            
            boxes = detect_faces_yolo(img)
            if boxes:
                x1, y1, x2, y2 = boxes[0]
                return JsonResponse({
                    "faces": [{"x1": x1, "y1": y1, "x2": x2, "y2": y2}]
                })
            
            return JsonResponse({"faces": []})
            
        except Exception as e:
            logger.error(f"Face detection error: {str(e)}")
            return JsonResponse({"error": str(e)}, status=500)
    
    return JsonResponse({"error": "Invalid request"}, status=400)

@csrf_exempt
def analyze_face(request):
    """Endpoint for face attribute analysis"""
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            image_data = data.get("image")
            
            if not image_data or ';base64,' not in image_data:
                return JsonResponse({"error": "Invalid image"}, status=400)

            img_bytes = base64.b64decode(image_data.split(';base64,')[1])
            img = cv2.imdecode(np.frombuffer(img_bytes, np.uint8), cv2.IMREAD_COLOR)
            
            analysis = DeepFace.analyze(
                img,
                actions=['age', 'gender', 'emotion', 'race'],
                enforce_detection=False,
                detector_backend='opencv',
                silent=True
            )
            
            if analysis:
                attrs = analysis[0]
                return JsonResponse({
                    "attributes": {
                        "age": int(attrs['age']),
                        "gender": attrs['dominant_gender'],
                        "emotion": attrs['dominant_emotion'],
                        "race": attrs['dominant_race']
                    }
                })
            
            return JsonResponse({"attributes": {}})
            
        except Exception as e:
            logger.error(f"Face analysis error: {str(e)}")
            return JsonResponse({"error": str(e)}, status=500)
    
    return JsonResponse({"error": "Invalid request"}, status=400)

@csrf_exempt
@transaction.atomic
def register_employee(request):
    if request.method == "POST":
        try:
            # Extract form data
            name = request.POST.get("name")
            designation = request.POST.get("designation")
            department = request.POST.get("department", 'IT')
            photo_base64 = request.POST.get("photo")
            embedding_str = request.POST.get("face_embedding")
            
            # Basic validation
            if not all([name, designation, photo_base64, embedding_str]):
                return JsonResponse({
                    "success": False, 
                    "error": "All fields are required.",
                    "error_type": "validation"
                }, status=400)

            # Process image and embedding
            format, imgstr = photo_base64.split(";base64,")
            image_bytes = base64.b64decode(imgstr)
            nparr = np.frombuffer(image_bytes, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            try:
                query_embedding = np.array(json.loads(embedding_str), dtype=np.float32)
            except:
                query_embedding = extract_face_embedding(img)
                if query_embedding is None:
                    return JsonResponse({
                        "success": False,
                        "error": "Could not generate face embedding.",
                        "error_type": "face_detection"
                    }, status=400)

            # Check for duplicate faces
            DUPLICATE_THRESHOLD = 0.85  # 85% similarity
            existing_employee = None
            max_similarity = 0.0
            
            for emp in Employee.objects.exclude(face_embedding=None):
                stored_embedding = emp.get_face_embedding()
                if stored_embedding is not None:
                    similarity = 1 - cosine(query_embedding, stored_embedding)
                    if similarity > max_similarity:
                        max_similarity = similarity
                        existing_employee = emp
                        if max_similarity > DUPLICATE_THRESHOLD:
                            break
            
            if existing_employee and max_similarity > DUPLICATE_THRESHOLD:
                return JsonResponse({
                    "success": False,
                    "error": f"This face matches existing employee: {existing_employee.name}",
                    "error_type": "face_duplicate",
                    "existing_employee": existing_employee.name,
                    "similarity": float(max_similarity)
                }, status=400)

            # IP-based rate limiting
            ip_address = request.META.get('REMOTE_ADDR', '')
            if EmployeeRegistrationRequest.objects.filter(
                ip_address=ip_address,
                status='pending',
                request_date__gte=timezone.now()-timedelta(hours=24)
            ).exists():
                return JsonResponse({
                    "success": False,
                    "error": "You already have a pending registration request.",
                    "error_type": "pending_exists"
                }, status=400)

            # Save registration request
            fs = FileSystemStorage()
            ext = format.split('/')[-1]
            image_name = f"temp_{int(timezone.now().timestamp())}.{ext}"
            temp_image_path = os.path.join(S.MEDIA_ROOT, "temp_uploads", image_name)
            os.makedirs(os.path.dirname(temp_image_path), exist_ok=True)
            
            with open(temp_image_path, "wb") as f:
                f.write(image_bytes)

            request_obj = EmployeeRegistrationRequest.objects.create(
                name=name,
                designation=designation,
                department=department,
                photo=f"temp_uploads/{image_name}",
                face_embedding=query_embedding.tolist(),
                ip_address=ip_address
            )
            
            return JsonResponse({
                "success": True,
                "message": "Registration submitted for approval",
                "request_id": request_obj.id
            })
            
        except Exception as e:
            logger.error(f"Registration error: {str(e)}", exc_info=True)
            return JsonResponse({
                "success": False, 
                "error": "Internal server error",
                "error_type": "server_error"
            }, status=500)

@csrf_exempt
def check_face_duplicate(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            embedding = np.array(data.get('embedding'), dtype=np.float32)
            
            if embedding is None or len(embedding) == 0:
                return JsonResponse({"error": "Invalid embedding"}, status=400)
                
            DUPLICATE_THRESHOLD = 0.85
            matches = []
            
            for emp in Employee.objects.exclude(face_embedding=None):
                stored_embedding = emp.get_face_embedding()
                if stored_embedding is not None:
                    similarity = 1 - cosine(embedding, stored_embedding)
                    if similarity > DUPLICATE_THRESHOLD:
                        matches.append({
                            "name": emp.name,
                            "employee_id": emp.employee_id,
                            "similarity": float(similarity)
                        })
            
            return JsonResponse({
                "is_duplicate": len(matches) > 0,
                "matches": matches
            })
            
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)
    
    return JsonResponse({"error": "Invalid request"}, status=400)

@login_required
def registration_requests(request):
    # Get all requests ordered by date
    requests = EmployeeRegistrationRequest.objects.all().order_by('-request_date')
    
    # Get counts for each status
    pending_count = requests.filter(status='pending').count()
    approved_count = requests.filter(status='approved').count()
    rejected_count = requests.filter(status='rejected').count()
    
    # Handle search query if present
    query = request.GET.get('q', '')
    if query:
        requests = requests.filter(
            Q(name__icontains=query) | 
            Q(department__icontains=query) |
            Q(designation__icontains=query)
        )
    
    return render(request, 'registration_requests.html', {
        'requests': requests,
        'pending_count': pending_count,
        'approved_count': approved_count,
        'rejected_count': rejected_count,
        'query': query
    })


def extract_face_embedding(image, debug=False):
    """Enhanced face embedding extraction with error handling"""
    try:
        if len(image.shape) == 2:
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        image = cv2.resize(image, (160, 160))
        image = (image - 127.5) / 128.0
        
        result = DeepFace.represent(
            image,
            model_name="Facenet512",
            detector_backend="skip",
            enforce_detection=False,
            align=True
        )
        
        if not result:
            if debug: logger.warning("No embedding generated")
            return None
            
        embedding = np.array(result[0]["embedding"], dtype=np.float32)
        
        # Validate embedding quality
        norm = np.linalg.norm(embedding)
        if norm < 0.1:
            if debug: logger.warning("Low quality embedding (norm too small)")
            return None
            
        return embedding
        
    except Exception as e:
        logger.error(f"Embedding extraction failed: {str(e)}")
        return None


def normalize_embedding(vec):
    norm = np.linalg.norm(vec)
    return vec / norm if norm > 0 else vec

def find_best_match(query_embedding, threshold=0.5):
    """Find matching employee using EmployeeEmbedding"""
    if query_embedding is None:
        return None, 0.0

    best_match = None
    best_score = 0.0

    # Get all embeddings with their employees
    embeddings = EmployeeEmbedding.objects.select_related('employee').all()
    
    for emb in embeddings:
        try:
            db_embedding = emb.get_embedding()
            if db_embedding is None:
                continue
                
            similarity = np.dot(
                normalize_embedding(query_embedding),
                normalize_embedding(db_embedding)
            )
            
            if similarity > best_score:
                best_score = similarity
                best_match = emb.employee
                
        except Exception as e:
            logger.warning(f"Error comparing embeddings: {str(e)}")
            continue

    return (best_match, best_score) if best_score >= threshold else (None, best_score)


def register_face_embedding(employee, embedding):
    embedding = normalize_embedding(np.array(embedding, dtype=np.float32))
    obj, created = EmployeeEmbedding.objects.get_or_create(employee=employee)
    obj.set_vector(embedding.tolist())
    logger.info(f"Face embedding {'created' if created else 'updated'} for {employee.name}")


def get_employee_embeddings():
    """Get all employee embeddings with caching"""
    global _employee_embeddings_cache, _last_cache_update
    
    current_time = t.time()
    if (_employee_embeddings_cache is None or 
        _last_cache_update is None or
        (current_time - _last_cache_update) > _CACHE_TIMEOUT):
        
        # Refresh cache
        embeddings = list(EmployeeEmbedding.objects.select_related('employee'))
        _employee_embeddings_cache = [
            (e.employee_id, normalize_embedding(np.array(e.vector, dtype=np.float32))) 
            for e in embeddings
        ]
        _last_cache_update = current_time
    
    return _employee_embeddings

"""========AUTHENTICATION VIEWS========"""
def login_view(request):
    settings = SystemSettings.load()
    
    if request.method == 'POST':
        username = request.POST.get('username', '').strip().lower()
        password = request.POST.get('password')
        ip_address = request.META.get('REMOTE_ADDR', '')
        print(ip_address)
        # Use a single cache key for all attempts from this IP
        cache_key = f"login_lockout:{ip_address}"
        lockout_until = cache.get(cache_key)
        
        if lockout_until and lockout_until > t.time():
            return render(request, 'login.html', {
                'locked': True,
                'time_remaining': int(lockout_until - t.time())
            })
        
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            # Clear any existing lockout
            cache.delete_many([
                f"login_lockout:{ip_address}",
                f"login_attempts:{ip_address}"
            ])
            login(request, user)
            request.session.cycle_key()
            return redirect('home')
        else:
            attempt_key = f"login_attempts:{ip_address}"
            attempts = cache.get(attempt_key, 0) + 1
            cache.set(attempt_key, attempts, settings.lockout_time)
            
            if attempts >= settings.max_login_attempts:
                lockout_until = t.time() + settings.lockout_time
                cache.set(cache_key, lockout_until, settings.lockout_time)
                return render(request, 'login.html', {
                    'locked': True,
                    'time_remaining': settings.lockout_time,
                    'attempts': attempts
                })
            
            messages.error(request, 
                f"Invalid credentials. {settings.max_login_attempts - attempts} attempts remaining")
    
    return render(request, 'login.html')

# Updated logout_view
def logout_view(request):
    logout(request)
    request.session.flush()
    
    # Check if logout was due to timeout
    if request.GET.get('timeout'):
        messages.warning(request, "Your session has expired due to inactivity.")
    
    response = redirect('login')
    response['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    response['Pragma'] = 'no-cache'
    response['Expires'] = '0'
    return response

"""========DASHBOARD VIEWS========"""
@login_required
def home(request):
    employees = Employee.objects.only('id', 'name', 'employee_id').count()
    today_attendance = Attendance.objects.filter(date=date.today()).select_related('emp')
    
    present_count = today_attendance.filter(status="Present").count()
    absent_count = employees - present_count
    
    return render(request, 'dashboard.html', {
        'total_employees': employees,
        'present_count': present_count,
        'absent_count': absent_count,
        'attendance_records': today_attendance[:10]
    })

def analyze_face_attributes(image):
    """Analyze face attributes with error handling"""
    try:
        analysis = DeepFace.analyze(
            image,
            actions=['age', 'gender', 'emotion'],
            enforce_detection=False,
            detector_backend='opencv',
            silent=True
        )
        
        if analysis:
            attrs = analysis[0]
            return {
                "age": int(attrs['age']),
                "gender": attrs['dominant_gender'],
                "emotion": attrs['dominant_emotion']
            }
        return None
    except Exception as e:
        logger.error(f"Face analysis error: {str(e)}")
        return None


def find_duplicate_employee(query_embedding, threshold):
    """Check if similar face already exists"""
    employees = Employee.objects.exclude(face_embedding=None)
    
    for emp in employees:
        stored_embedding = emp.get_face_embedding()
        if stored_embedding is None:
            continue
            
        similarity = 1 - cosine(query_embedding, stored_embedding)
        if similarity >= threshold:
            return emp
    return None

"""========ATTENDANCE VIEWS========"""
@login_required
@csrf_exempt
@transaction.atomic
def mark_attendance(request):
    settings = SystemSettings.load()
    END_TIME = getattr(settings, "attendance_end_time", time(23, 59, 59))
    CURRENT_TIME = datetime.now().time()

    if request.method != "POST":
        return render(request, "mark_attendance.html")

    try:
        # Image processing
        data = json.loads(request.body)
        image_data = data.get("image", "")
        
        if not image_data or ';base64,' not in image_data:
            return JsonResponse({"status": "error", "message": "Invalid image"}, status=400)

        img_bytes = base64.b64decode(image_data.split(';base64,')[1])
        img_np = np.frombuffer(img_bytes, np.uint8)
        frame = cv2.imdecode(img_np, cv2.IMREAD_COLOR)

        if frame is None:
            return JsonResponse({"status": "error", "message": "Invalid image"}, status=400)

        # Resize and pad to 640x640
        h, w = frame.shape[:2]
        scale = min(640/h, 640/w)
        new_h, new_w = int(h*scale), int(w*scale)
        frame = cv2.resize(frame, (new_w, new_h))

        pad_h = (640 - new_h) // 2
        pad_w = (640 - new_w) // 2
        frame = cv2.copyMakeBorder(
            frame, pad_h, 640-new_h-pad_h, pad_w, 640-new_w-pad_w,
            cv2.BORDER_CONSTANT, value=(0,0,0)
        )

        # Face detection
        boxes = detect_faces_yolo(frame)
        if not boxes:
            return JsonResponse({
                "status": "no_face", 
                "message": "No face detected",
                "boxes": []
            })

        response_data = {"boxes": []}
        today = date.today()

        for idx, box in enumerate(boxes):
            x1, y1, x2, y2 = box
            face_img = frame[y1:y2, x1:x2]

            # # Save face crop for debugging (optional)
            # debug_dir = os.path.join(S.MEDIA_ROOT, "debug_faces")
            # os.makedirs(debug_dir, exist_ok=True)
            # debug_path = os.path.join(debug_dir, f"face_{idx}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg")
            # cv2.imwrite(debug_path, face_img)

            # Extract embedding
            embedding = extract_face_embedding(face_img)
            emp, similarity = None, 0.0
            if embedding is not None:
                emp, similarity = find_best_match(embedding, settings.face_match_threshold)

            # Get face attributes
            attrs = {}
            try:
                analysis = DeepFace.analyze(
                    face_img,
                    actions=['age', 'gender', 'emotion','race'],
                    enforce_detection=False,
                    detector_backend='skip',
                    silent=True
                )
                if analysis:
                    attrs = {
                        "age": int(analysis[0]['age']),
                        "gender": str(analysis[0]['dominant_gender']),
                        "emotion": str(analysis[0]['dominant_emotion'])
                    }
            except Exception as e:
                logger.warning(f"Face analysis failed: {str(e)}")

            # Prepare response data
            box_info = {
                "x1": int(x1), 
                "y1": int(y1), 
                "x2": int(x2), 
                "y2": int(y2),
                "name": str(emp.name) if emp else "Unknown",
                "emp_id": str(emp.employee_id) if emp else "--",
                "dept": str(emp.department) if emp else "--",
                "similarity": float(similarity),  # Convert numpy.float32 to float
                **attrs
            }

            # Attendance logic
            if emp:
                existing = Attendance.objects.filter(emp=emp, date=today).first()

                if existing:
                    box_info["status"] = "already_marked"
                    box_info["time"] = existing.time.strftime("%H:%M:%S")
                else:
                    if CURRENT_TIME <= END_TIME:
                        Attendance.objects.create(
                            emp=emp,
                            date=today,
                            time=CURRENT_TIME,
                            status="Present"
                        )
                        box_info["status"] = "marked"
                    else:
                        box_info["status"] = "late"
            else:
                box_info["status"] = "unregistered"

            response_data["boxes"].append(box_info)

        # Determine overall status
        if any(box.get("status") == "marked" for box in response_data["boxes"]):
            response_data["status"] = "marked"
            response_data["message"] = "Attendance marked successfully"
        elif any(box.get("status") == "already_marked" for box in response_data["boxes"]):
            response_data["status"] = "already_marked"
            response_data["message"] = "Attendance already recorded"
        else:
            response_data["status"] = "unregistered"
            response_data["message"] = "No registered employee detected"

        # Convert numpy types to native Python types for JSON serialization
        def convert_numpy_types(obj):
            if isinstance(obj, np.generic):
                return obj.item()
            elif isinstance(obj, np.ndarray):
                return obj.tolist()
            elif isinstance(obj, dict):
                return {k: convert_numpy_types(v) for k, v in obj.items()}
            elif isinstance(obj, (list, tuple)):
                return [convert_numpy_types(v) for v in obj]
            return obj

        response_data = convert_numpy_types(response_data)
        return JsonResponse(response_data)

    except Exception as e:
        logger.error(f"Attendance error: {str(e)}", exc_info=True)
        return JsonResponse({
            "status": "error",
            "message": str(e),
            "boxes": []
        }, status=500)


"""========REPORTING VIEWS========"""
@login_required
def export_attendance(request):
    response = HttpResponse(content_type='text/csv; charset=utf-8-sig')
    response['Content-Disposition'] = f'attachment; filename="attendance_{date.today().strftime("%Y-%m-%d")}.csv"'
    response.write('\ufeff')
    
    writer = csv.writer(response)
    writer.writerow(['Employee ID', 'Name', 'Date', 'Status', 'Time'])
    
    for record in Attendance.objects.select_related('emp').only(
        'date', 'status', 'time', 'emp__employee_id', 'emp__name'
    ):
        writer.writerow([
            record.emp.employee_id,
            record.emp.name,
            record.date.strftime('%m/%d/%Y'),
            record.status,
            record.time.strftime('%H:%M:%S')
        ])
    
    return response

"""========SYSTEM FUNCTIONS========"""
def mark_absent_employees():
    from .scheduler import get_scheduler, start_scheduler
    scheduler = get_scheduler()
    today = date.today()
    settings = SystemSettings.load()

    try:
        with transaction.atomic():
            # Get present employees
            present_ids = list(Attendance.objects.filter(
                date=today,
                status="Present"
            ).values_list('emp_id', flat=True))

            # Get employees with approved leave
            on_leave = list(LeaveApplication.objects.filter(
                status='Approved',
                start_date__lte=today,
                end_date__gte=today
            ).values_list('employee_id', flat=True))

            # Create absent records
            absent_count = 0
            for emp in Employee.objects.exclude(
                Q(id__in=present_ids) | Q(id__in=on_leave)
            ):
                try:
                    if not Attendance.objects.filter(emp=emp, date=today).exists():
                        Attendance.objects.create(
                            emp=emp,
                            date=today,
                            time=settings.absent_time,
                            status="Absent",
                            is_locked=True,
                            marked_by="System"
                        )
                        absent_count += 1
                        t.sleep(0.1)  # Small delay between inserts
                except Exception as e:
                    logger.error(f"Error marking absent for {emp}: {str(e)}")
                    continue

            # Create leave records
            leave_count = 0
            for emp_id in on_leave:
                try:
                    if emp_id not in present_ids:
                        emp = Employee.objects.get(id=emp_id)
                        if not Attendance.objects.filter(emp=emp, date=today).exists():
                            Attendance.objects.create(
                                emp=emp,
                                date=today,
                                time=settings.absent_time,
                                status="Leave",
                                is_locked=True,
                                marked_by="System"
                            )
                            leave_count += 1
                            t.sleep(0.1)  # Small delay between inserts
                except Exception as e:
                    logger.error(f"Error marking leave for {emp_id}: {str(e)}")
                    continue

            logger.info(f"Marked {absent_count} as absent, {leave_count} on leave")
    except Exception as e:
        logger.error(f"Error in mark_absent_employees: {str(e)}")
        # Retry after delay
        t.sleep(5)
        mark_absent_employees()

                 
@login_required
def update_absent_time(request):
    if request.method == "POST":
        try:
            time_str = request.POST.get("absent_time")
            
            if not time_str:
                messages.error(request, "⏰ Time field is required.")
                return redirect('mysetting')

            try:
                hour, minute = map(int, time_str.split(':'))
                if not (8 <= hour <= 18):
                    messages.error(request, "⚠️ Time must be between 8:00 AM and 6:00 PM")
                    return redirect('mysetting')
                    
                new_time = time(hour, minute)

                # Update settings
                with transaction.atomic():
                    settings = SystemSettings.load()
                    settings.absent_time = new_time
                    settings.save()
                    
                    AbsentTimeSettings.objects.update_or_create(
                        id=1,
                        defaults={'absent_time': new_time}
                    )

                logger.info(f"Absent time updated to {new_time} by {request.user.username}")

                # Restart scheduler (no try/except needed here now)
                scheduler_manager.start_scheduler()
                
                # Confirm if scheduler job is active
                job = scheduler_manager.get_scheduler().get_job('mark_absent_employees')
                if job:
                    next_run = job.next_run_time
                    messages.success(request, 
                        f"✅ Absent time updated to {new_time.strftime('%I:%M %p')}\n"
                        f"Next automatic marking at {next_run.strftime('%I:%M %p')}"
                    )
                else:
                    messages.warning(request, "⚠️ Scheduler job not found - please check logs")

                return redirect('mysetting')

            except ValueError as e:
                logger.warning(f"Invalid time format: {time_str} - {str(e)}")
                messages.error(request, "⚠️ Invalid time format. Please use HH:MM format.")
                return redirect('mysetting')

        except Exception as e:
            logger.error(f"Error updating absent time: {str(e)}", exc_info=True)
            messages.error(request, "❌ An unexpected error occurred. Please try again.")
            return redirect('mysetting')

    return redirect('mysetting')


"""========DATA VIEWS========"""
@login_required
def attendance_view(request):
    query = request.GET.get('q', '')  
    attendance_records = Attendance.objects.select_related('emp').order_by('-date')

    if query:
        attendance_records = attendance_records.filter(
            Q(emp__name__icontains=query) | 
            Q(emp__department__icontains=query)
        )

    return render(request, 'attendance.html', {
        'attendance_records': attendance_records, 
        'query': query
    })

@login_required
def analysis(request):
    query = request.GET.get('q', '')
    employees = Employee.objects.all()
    total_employees = employees.count()

    today = date.today()
    present_count = Attendance.objects.filter(
        date=today, 
        status="Present"
    ).count()
    absent_count = total_employees - present_count

    employees = employees.annotate(
        present_days=Count(
            'attendance_records',
            filter=Q(attendance_records__status="Present")
        ),
        absent_days=Count(
            'attendance_records',
            filter=Q(attendance_records__status="Absent")
        ),
        leave_days=Count(
            'attendance_records',
            filter=Q(attendance_records__status="Leave")
        ),
        total_days=Count('attendance_records')
    ).annotate(
        attendance_percentage=Case(
            When(total_days=0, then=0.0),
            default=100.0 * F('present_days') / F('total_days'),
            output_field=FloatField()
        )
    ).order_by('name')

    if query:
        employees = employees.filter(
            Q(name__icontains=query) | 
            Q(department__icontains=query)
        )

    return render(request, 'analysis.html', {
        'total_employees': total_employees,
        'present_count': present_count,
        'absent_count': absent_count,
        'employees': employees,
        'query': query,
    })

"""========USER MANAGEMENT VIEWS========"""
@login_required
def all_users(request):
    query = request.GET.get('q', '')  
    users = Employee.objects.all()

    if query:
        users = users.filter(
            Q(name__icontains=query) | 
            Q(department__icontains=query)
        )

    return render(request, 'all_users.html', {'users': users, 'query': query})

@login_required
def present_users(request):
    query = request.GET.get('q', '')  
    today = date.today()
    present_users = Attendance.objects.filter(
        date=today, 
        status="Present"
    ).select_related('emp')

    if query:
        present_users = present_users.filter(
            Q(emp__name__icontains=query) | 
            Q(emp__department__icontains=query)
        )

    return render(request, 'present_users.html', {
        'present_users': present_users, 
        'query': query
    })

@login_required
def absent_users(request):
    query = request.GET.get('q', '')  
    today = date.today()
    
    present_ids = Attendance.objects.filter(
        date=today, 
        status="Present"
    ).values_list('emp_id', flat=True)
    
    absent_users = Employee.objects.exclude(id__in=present_ids)
    
    if query:
        absent_users = absent_users.filter(
            Q(name__icontains=query) | 
            Q(department__icontains=query)
        )

    return render(request, 'absent_users.html', {
        'absent_users': absent_users, 
        'query': query
    })

"""========USER CRUD OPERATIONS========"""
@login_required
def delete_user(request, user_id):
    user = get_object_or_404(Employee, id=user_id)
    if request.method == 'POST':
        user.delete()
        return JsonResponse({'message': 'User deleted successfully'}, status=200)
    return JsonResponse({'error': 'Invalid request'}, status=400)

@login_required
def edit_user(request, user_id):
    user = get_object_or_404(Employee, id=user_id)

    if request.method == 'POST':
        user.name = request.POST.get('name')
        user.department = request.POST.get('department')
        user.designation = request.POST.get('designation')
        user.save()
        return JsonResponse({'message': 'User updated successfully'})
    
    return JsonResponse({
        'name': user.name,
        'department': user.department,
        'designation': user.designation,
    })

"""========SYSTEM SETTINGS========"""
@login_required
def mysetting(request):
    settings = SystemSettings.load()
    absent_settings = AbsentTimeSettings.objects.first()
    
    if request.method == "POST":
        user = request.user
        
        if 'username' in request.POST or 'password' in request.POST:
            new_username = request.POST.get("new")
            new_password = request.POST.get("password")
            old_password = request.POST.get("old")
            confirm_password = request.POST.get("cpassword")

            if new_username:
                user.username = new_username
                user.save()
                messages.success(request, "Username updated successfully.")

            if old_password and new_password and confirm_password:
                if user.check_password(old_password):
                    if new_password == confirm_password:
                        user.set_password(new_password)
                        user.save()
                        update_session_auth_hash(request, user)
                        messages.success(request, "Password updated successfully.")
                    else:
                        messages.error(request, "New passwords do not match.")
                else:
                    messages.error(request, "Old password is incorrect.")
            elif new_password or confirm_password or old_password:
                messages.error(request, "Please fill all password fields to change the password.")
    
    return render(request, 'mysetting.html', {
        'user': request.user,
        'settings': settings,
        'absent_time': absent_settings.absent_time if absent_settings else time(12, 0)
    })

class EmployeePortalView(TemplateView):
    template_name = 'employee_portal.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.user.is_authenticated and hasattr(self.request.user, 'employee'):
            employee = self.request.user.employee
            last_request = EmployeeRegistrationRequest.objects.filter(
                employee=employee
            ).order_by('-request_date').first()
            
            if last_request:
                context['registration_status'] = last_request.status
                if last_request.status == 'rejected':
                    context['rejection_reason'] = last_request.admin_comment or "No specific reason provided"
        return context

@login_required
def registration_requests(request):
    # Get all requests ordered by date
    requests = EmployeeRegistrationRequest.objects.all().order_by('-request_date')
    
    # Get counts for each status
    pending_count = requests.filter(status='pending').count()
    approved_count = requests.filter(status='approved').count()
    rejected_count = requests.filter(status='rejected').count()
    
    # Handle search query if present
    query = request.GET.get('q', '')
    if query:
        requests = requests.filter(
            Q(name__icontains=query) | 
            Q(department__icontains=query) |
            Q(designation__icontains=query)
        )
    
    return render(request, 'registration_requests.html', {
        'requests': requests,
        'pending_count': pending_count,
        'approved_count': approved_count,
        'rejected_count': rejected_count,
        'query': query
    })


@login_required
@require_POST
def process_registration_request(request, request_id):
    registration_request = get_object_or_404(EmployeeRegistrationRequest, id=request_id)
    action = request.POST.get('action')
    comment = request.POST.get('comment', '')

    if action == 'approve':
        try:
            employee = registration_request.approve()
            messages.success(request, f"Registration approved for {employee.name}")
        except Exception as e:
            messages.error(request, f"Error approving registration: {str(e)}")
    elif action == 'reject':
        registration_request.reject(comment)
        messages.warning(request, f"Registration rejected for {registration_request.name}")
    
    return redirect('registration_requests')

@csrf_exempt
def check_registration_status(request):
    if request.method == "GET":
        request_id = request.GET.get('request_id')
        if not request_id:
            return JsonResponse({'status': 'not_found'})
        
        try:
            registration_request = EmployeeRegistrationRequest.objects.get(id=request_id)
            return JsonResponse({
                'status': registration_request.status,
                'reason': registration_request.admin_comment
            })
        except EmployeeRegistrationRequest.DoesNotExist:
            return JsonResponse({'status': 'not_found'})
    
    return JsonResponse({'error': 'Invalid request'}, status=400)

@csrf_exempt
def emp_login(request):
    if request.method == "POST":
        try:
            # Get image data from request
            image_data = request.POST.get("image")
            if not image_data or ';base64,' not in image_data:
                return JsonResponse({"success": False, "error": "Image required"}, status=400)

            # Process image
            img_bytes = base64.b64decode(image_data.split(';base64,')[1])
            img = cv2.imdecode(np.frombuffer(img_bytes, np.uint8), cv2.IMREAD_COLOR)
            
            if img is None:
                return JsonResponse({"success": False, "error": "Invalid image format"}, status=400)

            # Resize image for better processing
            img = cv2.resize(img, (640, 640))
            
            # Detect faces
            boxes = detect_faces_yolo(img)
            if not boxes:
                return JsonResponse({"success": False, "error": "No face detected"}, status=400)

            # Extract face embedding
            x1, y1, x2, y2 = boxes[0]  # Take first face
            face_img = img[y1:y2, x1:x2]
            embedding = extract_face_embedding(face_img)
            
            if embedding is None:
                return JsonResponse({"success": False, "error": "Failed to extract facial features"}, status=400)

            # Find matching employee
            settings = SystemSettings.load()
            best_match, best_similarity = find_best_match(embedding, settings.face_match_threshold)
            
            if not best_match:
                return JsonResponse({
                    "success": False, 
                    "error": f"No matching employee found (similarity: {best_similarity:.2f})"
                }, status=400)

            # Check if employee is active (approved)
            if not best_match.is_active:
                return JsonResponse({
                    "success": False,
                    "error": "Your registration is pending approval or has been rejected"
                }, status=403)
            
            # Set session data
            request.session['emp_id'] = best_match.id
            request.session['emp_name'] = best_match.name
            request.session.set_expiry(3600)  # 1 hour session
            
            return JsonResponse({
                "success": True,
                "name": best_match.name,
                "employee_id": best_match.employee_id,
                "similarity": float(best_similarity),
                "redirect_url": reverse('emp_dashboard')
            })

        except Exception as e:
            logger.error(f"Employee login error: {str(e)}", exc_info=True)
            return JsonResponse({"success": False, "error": "Internal server error"}, status=500)

    # GET request - show login form
    return render(request, 'emp_login.html', {
        'next': request.GET.get('next', '')
    })



def emp_logout(request):
    if 'emp_id' in request.session:
        del request.session['emp_id']
    if 'emp_name' in request.session:
        del request.session['emp_name']
    return redirect('emp_login')


@never_cache
def emp_dashboard(request):
    emp_id = request.session.get('emp_id')
    if not emp_id:
        return redirect('emp_login')
    
    try:
        employee = Employee.objects.select_related('user').get(id=emp_id)
        user = request.user  # Get the authenticated user
        
        # # Update the last login time if this is a new session
        # if 'last_login' not in request.session:
        #     request.session['last_login'] = str(user.last_login)
            
            
    except Employee.DoesNotExist:
        logout(request)
        return redirect('emp_login')
    
    today = date.today()
    settings = SystemSettings.load()
    
    # Today's attendance
    today_attendance = Attendance.objects.filter(
        emp=employee,
        date=today
    ).first()
    
    # Monthly stats
    current_month = today.month
    current_year = today.year
    
    monthly_attendance = Attendance.objects.filter(
        emp=employee,
        date__year=current_year,
        date__month=current_month
    )
    
    present_days = monthly_attendance.filter(status="Present").count()
    absent_days = monthly_attendance.filter(status="Absent").count()
    leave_days = monthly_attendance.filter(status="Leave").count()
    total_working_days = today.day
    
    # Leave applications
    leave_applications = LeaveApplication.objects.filter(
        employee=employee
    ).order_by('-application_date')
    
    # Refresh employee data to ensure we have latest leave balances
    employee.refresh_from_db()
    
    return render(request, 'emp_dashboard.html', {
        'employee': employee,
        # 'user': user,  
        'today_attendance': today_attendance,
        'present_days': present_days,
        'absent_days': absent_days,
        'leave_days': leave_days,
        'total_working_days': total_working_days,
        'leave_applications': leave_applications,
        'annual_leave_limit': settings.annual_leave_limit,
        'sick_leave_limit': settings.sick_leave_limit,
        'annual_leave_remaining': employee.annual_leave_remaining,
        'sick_leave_remaining': employee.sick_leave_remaining,
        'last_login': request.session.get('last_login')  # Pass last login time
    })

@login_required
@transaction.atomic
def apply_leave(request):
    if request.method == "POST":
        try:
            emp_id = request.session.get('emp_id')
            if not emp_id:
                messages.error(request, "Session expired. Please login again.")
                return redirect('emp_login')

            employee = get_object_or_404(Employee, id=emp_id)
            
            # Get form data
            leave_type = request.POST.get('leave_type')
            department = request.POST.get('department')
            start_date_str = request.POST.get('start_date')
            end_date_str = request.POST.get('end_date')
            reason = request.POST.get('reason')
            attachment = request.FILES.get('attachment')
            
            # Validate required fields
            if not all([leave_type, department, start_date_str, end_date_str, reason]):
                messages.error(request, "All required fields must be filled.")
                return redirect('emp_dashboard')
            
            try:
                start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
                end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
            except ValueError as e:
                messages.error(request, f"Invalid date format: {str(e)}")
                return redirect('emp_dashboard')
                
            if start_date > end_date:
                messages.error(request, "End date must be after start date")
                return redirect('emp_dashboard')
            
            if start_date < date.today():
                messages.error(request, "Cannot apply for leave in the past")
                return redirect('emp_dashboard')
                
            leave_days = (end_date - start_date).days + 1
            
            # Check leave balance
            if leave_type == 'Annual':
                if employee.annual_leave_remaining < leave_days:
                    messages.error(request, 
                        f"Insufficient annual leave balance. You have {employee.annual_leave_remaining} days remaining.")
                    return redirect('emp_dashboard')
            elif leave_type == 'Sick':
                if employee.sick_leave_remaining < leave_days:
                    messages.error(request, 
                        f"Insufficient sick leave balance. You have {employee.sick_leave_remaining} days remaining.")
                    return redirect('emp_dashboard')
            
            # Check for overlapping leaves
            overlapping = LeaveApplication.objects.filter(
                employee=employee,
                start_date__lte=end_date,
                end_date__gte=start_date
            ).exclude(status='Rejected').exists()
            
            if overlapping:
                messages.error(request, "You already have a leave application for this period")
                return redirect('emp_dashboard')
            
            # Handle file upload
            attachment_path = None
            if attachment:
                if attachment.size > 5 * 1024 * 1024:  # 5MB limit
                    messages.error(request, "File size exceeds 5MB limit")
                    return redirect('emp_dashboard')
                
                valid_types = ['application/pdf', 'image/jpeg', 'image/png']
                if attachment.content_type not in valid_types:
                    messages.error(request, "Invalid file type. Only PDF, JPG, and PNG allowed")
                    return redirect('emp_dashboard')
                
                attachment_dir = os.path.join(S.MEDIA_ROOT, 'leave_attachments')
                os.makedirs(attachment_dir, exist_ok=True)
                
                filename = f'{employee.employee_id}_{int(t.time())}_{attachment.name}'
                attachment_path = os.path.join('leave_attachments', filename)
                
                fs = FileSystemStorage()
                fs.save(attachment_path, attachment)
            
            # Create leave application (don't deduct leaves yet - wait for approval)
            leave_app = LeaveApplication(
                employee=employee,
                leave_type=leave_type,
                dept=department,
                reason=reason,
                start_date=start_date,
                end_date=end_date,
                status='Pending',
                attachment=attachment_path
            )
            leave_app.save()

            messages.success(request, 
                f"Leave application submitted successfully for {leave_days} day(s). Waiting for approval.")
            return redirect('emp_dashboard')
            
        except Exception as e:
            logger.error(f"Leave application error: {str(e)}", exc_info=True)
            messages.error(request, "An error occurred. Please try again.")
            return redirect('emp_dashboard')
    
    return redirect('emp_dashboard')

@login_required
def leave_management(request):
    applications = LeaveApplication.objects.select_related('employee').order_by('-application_date')

    return render(request, 'leave_management.html', {
    'applications': applications
})

@login_required
@require_POST
@transaction.atomic
def process_leave(request, app_id, action):
    try:
        # Fetch leave application and lock employee for safe update
        application = get_object_or_404(LeaveApplication, id=app_id)
        employee = Employee.objects.select_for_update().get(id=application.employee.id)
        settings = SystemSettings.load()

        data = json.loads(request.body)
        comment = data.get('comment', '')

        if action == 'approve':
            # Calculate total leave days (inclusive)
            leave_days = (application.end_date - application.start_date).days + 1

            # Refresh employee data to avoid stale balance
            employee.refresh_from_db()

            # Approve logic based on leave type
            if application.leave_type == 'Annual Leave':
                if employee.annual_leave_remaining < leave_days:
                    return JsonResponse({
                        'status': 'error',
                        'message': f'Not enough Annual Leave remaining. You have {employee.annual_leave_remaining} days, but {leave_days} days needed.'
                    }, status=400)
                employee.annual_leave_remaining -= leave_days

            elif application.leave_type == 'Sick Leave':
                if employee.sick_leave_remaining < leave_days:
                    return JsonResponse({
                        'status': 'error',
                        'message': f'Not enough Sick Leave remaining. You have {employee.sick_leave_remaining} days, but {leave_days} days needed.'
                    }, status=400)
                employee.sick_leave_remaining -= leave_days

            else:
                return JsonResponse({
                    'status': 'error',
                    'message': f'Invalid leave type: {application.leave_type}'
                }, status=400)

            # Always update total leave taken
            employee.total_leave_taken += leave_days
            employee.save()

            # Update leave application status
            application.status = 'Approved'
            application.admin_comment = comment
            application.days_count = leave_days
            application.save()

            return JsonResponse({
                'status': 'success', 
                'message': 'Leave approved and balance updated.',
                'remaining_annual': employee.annual_leave_remaining,
                'remaining_sick': employee.sick_leave_remaining,
                'annual_limit': settings.annual_leave_limit,
                'sick_limit': settings.sick_leave_limit
            })

        elif action == 'reject':
            # Simply reject the application
            application.status = 'Rejected'
            application.admin_comment = comment
            application.save()

            return JsonResponse({'status': 'success', 'message': 'Leave application rejected.'})

        else:
            return JsonResponse({'status': 'error', 'message': 'Invalid action.'}, status=400)

    except Exception as e:
        logger.error(f"Error processing leave: {str(e)}", exc_info=True)
        return JsonResponse({'status': 'error', 'message': 'An error occurred. Please try again later.'}, status=500)
    

@login_required
@require_POST
@transaction.atomic
def update_leave_limits(request):
    try:
        annual_limit = int(request.POST.get('annual_leave_limit'))
        sick_limit = int(request.POST.get('sick_leave_limit'))

        if annual_limit <= 0 or sick_limit <= 0:
            messages.error(request, "Leave limits must be positive numbers")
            return redirect('mysetting')

        # Get current settings
        settings = SystemSettings.load()
        
        # Calculate adjustments
        annual_adjustment = annual_limit - settings.annual_leave_limit
        sick_adjustment = sick_limit - settings.sick_leave_limit
        
        # Update SystemSettings - this will trigger the employee updates via save()
        settings.annual_leave_limit = annual_limit
        settings.sick_leave_limit = sick_limit
        settings.save()

        messages.success(request, 
            f"Leave limits updated successfully. Adjusted {annual_adjustment:+d} annual "
            f"and {sick_adjustment:+d} sick days for all employees."
        )
        return redirect('mysetting')

    except (ValueError, TypeError) as e:
        messages.error(request, "Invalid leave limit values")
        return redirect('mysetting')
    except Exception as e:
        logger.error(f"Error updating leave limits: {str(e)}")
        messages.error(request, "An error occurred while updating leave limits")
        return redirect('mysetting')
