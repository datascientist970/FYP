from django.apps import AppConfig
import threading
import logging
from django.db.models.signals import post_migrate

logger = logging.getLogger(__name__)

class AttendenceConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "attendence"
    scheduler_started = False

    def ready(self):
        # Import here to avoid circular imports
        from .signals import init_system
        
        # Connect to post_migrate signal
        post_migrate.connect(init_system, sender=self)
        
        # Start scheduler in background thread
        self.start_scheduler_safe()

    def start_scheduler_safe(self):
        """Safely start the scheduler in a background thread"""
        if self.scheduler_started:
            return

        def run_scheduler():
            """Inner function to run the scheduler"""
            try:
                from .scheduler import start_scheduler
                start_scheduler()
                self.scheduler_started = True
                logger.info("Scheduler started successfully")
            except Exception as e:
                logger.error(f"Failed to start scheduler: {e}")

        try:
            # Start in a daemon thread (will exit when main thread exits)
            thread = threading.Thread(target=run_scheduler, daemon=True)
            thread.start()
        except Exception as e:
            logger.error(f"Error starting scheduler thread: {e}")