from django.core.management.base import BaseCommand
import numpy as np
from attendence.models import EmployeeEmbedding

class Command(BaseCommand):
    help = 'Verifies all stored face embeddings'

    def handle(self, *args, **options):
        embeddings = EmployeeEmbedding.objects.select_related('employee').all()
        
        self.stdout.write(f"Checking {embeddings.count()} embeddings...")
        
        for emb in embeddings:
            try:
                vec = np.array(emb.vector, dtype=np.float32)
                norm = np.linalg.norm(vec)
                
                # Self-test
                match, score = find_best_match(vec, threshold=0.3)
                
                self.stdout.write(
                    f"{emb.employee.name.ljust(20)}: "
                    f"Norm: {norm:.2f} | "
                    f"Self-match: {match == emb.employee} | "
                    f"Score: {score:.4f}"
                )
                
                if norm < 0.1 or norm > 2.0:
                    self.stderr.write(f"  ⚠️ Abnormal norm value for {emb.employee.name}")
                
            except Exception as e:
                self.stderr.write(f"Error checking {emb.employee.name}: {str(e)}")