from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
import getpass  

User = get_user_model()

class Command(BaseCommand):
    help = "Create a superuser interactively"

    def handle(self, *args, **kwargs):
        """Create a superuser interactively with user input."""
        try:
            username = input("Enter admin username: ").strip()
            email = input("Enter admin email: ").strip()
            
            password = getpass.getpass("Enter password: ").strip() 
            confirm_password = getpass.getpass("Confirm password: ").strip()  

            if password != confirm_password:
                self.stdout.write(self.style.ERROR("❌ Passwords do not match. Please try again."))
                return

            if User.objects.filter(is_superuser=True).exists():
                self.stdout.write(self.style.WARNING("⚠️ A superuser already exists. Cannot create another."))
                return

            User.objects.create_superuser(username=username, email=email, password=password)
            self.stdout.write(self.style.SUCCESS(f"✅ Superuser '{username}' created successfully!"))

        except ValidationError as e:
            self.stdout.write(self.style.ERROR(f"❌ {e.messages[0]}"))
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"❌ An unexpected error occurred: {str(e)}"))
