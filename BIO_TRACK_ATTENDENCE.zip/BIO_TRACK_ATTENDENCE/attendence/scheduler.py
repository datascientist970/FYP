from datetime import datetime
from .models import SystemSettings
from apscheduler.executors.pool import ThreadPoolExecutor
from apscheduler.triggers.cron import CronTrigger
import time as t
import logging
import atexit
from django.db import close_old_connections

logger = logging.getLogger(__name__)

class SchedulerManager:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._init_scheduler()
        return cls._instance

    def _init_scheduler(self):
        from apscheduler.schedulers.background import BackgroundScheduler
        from django_apscheduler.jobstores import DjangoJobStore

        self._executor = ThreadPoolExecutor(1)
        self._scheduler = BackgroundScheduler(
            executors={'default': self._executor},
            jobstores={'default': DjangoJobStore()},
            timezone='Asia/Karachi'
        )
        logger.info("Scheduler initialized")
        atexit.register(self.shutdown)

    def get_scheduler(self):
        return self._scheduler

    def start_scheduler(self):
        """Start or restart the scheduler with current settings"""
        try:
            close_old_connections()
            settings = SystemSettings.load()

            new_trigger = CronTrigger(
                hour=settings.absent_time.hour,
                minute=settings.absent_time.minute,
                timezone='Asia/Karachi'
            )

            # Remove old job if exists
            current_job = self._scheduler.get_job('mark_absent_employees')
            if current_job:
                current_job.remove()

            # Add new job
            self._scheduler.add_job(
                scheduled_mark_absent,   # <-- Top level function now
                trigger=new_trigger,
                id='mark_absent_employees',
                replace_existing=True,
                misfire_grace_time=3600,
                max_instances=1
            )

            if not self._scheduler.running:
                self._scheduler.start()
                logger.info("Scheduler started successfully")

            next_run = self._scheduler.get_job('mark_absent_employees').next_run_time
            logger.info(f"Next absent marking at {next_run}")

        except Exception as e:
            logger.error(f"Scheduler error: {str(e)}", exc_info=True)
            raise
        finally:
            close_old_connections()

    def shutdown(self):
        """Graceful shutdown"""
        try:
            if self._scheduler.running:
                self._scheduler.shutdown(wait=True)
                logger.info("Scheduler shut down successfully")

            self._executor.shutdown(wait=True)
            logger.info("Executor shut down successfully")

        except Exception as e:
            logger.error(f"Error during shutdown: {str(e)}")
        finally:
            close_old_connections()

# Singleton instance
scheduler_manager = SchedulerManager()

# ✅ Top-level job function (must be outside class)
def scheduled_mark_absent():
    """Job function to mark absents"""
    try:
        close_old_connections()
        logger.info("Starting absent employee marking...")
        from .views import mark_absent_employees
        mark_absent_employees()
        logger.info("Absent marking completed.")
    except Exception as e:
        logger.error(f"Error in scheduled_mark_absent: {str(e)}", exc_info=True)
    finally:
        close_old_connections()

# ✅ Convenience functions
def get_scheduler():
    return scheduler_manager.get_scheduler()

def start_scheduler():
    return scheduler_manager.start_scheduler()
