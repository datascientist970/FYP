import sqlite3
from django.db.utils import DatabaseError

class SQLiteRouter:
    def db_for_read(self, model, **hints):
        return 'default'

    def db_for_write(self, model, **hints):
        try:
            return 'default'
        except sqlite3.OperationalError:
            raise DatabaseError("Database is locked - please try again later")
            
    def allow_relation(self, obj1, obj2, **hints):
        return True

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        return True